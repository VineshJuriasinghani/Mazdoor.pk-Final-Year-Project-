package com.example.mazdoor_pk

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
